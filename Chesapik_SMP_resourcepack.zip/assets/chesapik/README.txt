Ресурспак Chesapik SMP — как заменить заглушки своими моделями

Сейчас каждая шляпа/скин показывает ванильную модель-заглушку (например, блок шерсти на голове).
Чтобы сделать свою:
1) Нарисуй модель в Blockbench (Java Block/Item), экспортируй JSON-модель и текстуру.
2) Положи модель в   assets/chesapik/models/hat/witch_hat.json
   текстуру в        assets/chesapik/textures/item/hat/witch_hat.png
   (в модели укажи "textures": {"0": "chesapik:item/hat/witch_hat"})
3) В файле assets/chesapik/items/hat/witch_hat.json поменяй
   "model": "minecraft:block/purple_wool"  ->  "model": "chesapik:hat/witch_hat"
Для шляп настрой в Blockbench вкладку Display -> Head, чтобы шляпа правильно сидела на голове.
Для скинов оружия — то же самое, только папка skin/ и Display -> Thirdperson/Firstperson.

Текстура NPC-манекена из ресурспака: положи PNG скина 64x64 в
   assets/chesapik/textures/entity/npc/trader.png
и спавни NPC функцией chesapik:npc/spawn_mannequin_tex {..., texture:"chesapik:entity/npc/trader"}
